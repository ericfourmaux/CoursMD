
<template><canvas ref="cv" width="300" height="60"></canvas></template>
<script setup lang="ts">
import { onMounted, ref } from 'vue';
import { useAudioEngine } from '@/composables/useAudioEngine';
const { engine } = useAudioEngine(); const cv = ref<HTMLCanvasElement>();
onMounted(() => {
  const c = cv.value!.getContext('2d')!; const an = engine.analyserNode; const buf = new Float32Array(an.fftSize);
  function draw(){ an.getFloatTimeDomainData(buf); let acc=0, pk=0; for(let i=0;i<buf.length;i++){ acc+=buf[i]*buf[i]; pk=Math.max(pk,Math.abs(buf[i])); }
    const rms = Math.sqrt(acc/buf.length); c.clearRect(0,0,300,60); c.fillStyle='#1f77b4'; c.fillRect(10,40,280*rms,10); c.fillStyle='#d62728'; c.fillRect(10+280*pk,20,2,30); requestAnimationFrame(draw);
  } requestAnimationFrame(draw);
});
</script>
