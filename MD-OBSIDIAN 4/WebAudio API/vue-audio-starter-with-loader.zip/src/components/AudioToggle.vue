
<template>
  <button @click="onEnable" :disabled="running">🎵 Activer le son</button>
</template>
<script setup lang="ts">
import { useAudioEngine } from '@/composables/useAudioEngine';
const { running, enable } = useAudioEngine();
async function onEnable(){ await enable(); }
</script>
