
<template>
  <div class="transport">
    <label>BPM <input type="number" v-model.number="bpm"/></label>
    <label>Swing <input type="range" min="0.5" max="0.75" step="0.01" v-model.number="swing"/></label>
    <button @click="onPlay">Play</button>
    <button @click="onPause">Pause</button>
  </div>
</template>
<script setup lang="ts">
import { store } from '@/store/sequencer';
import { useAudioEngine } from '@/composables/useAudioEngine';
import { Transport } from '@/audio/transport';
const { engine, enable } = useAudioEngine();
const transport = new Transport(engine);

const bpm = $ref(store.bpm);
const swing = $ref(store.swing);

watch(() => bpm, (v)=> store.bpm = v);
watch(() => swing, (v)=> store.swing = v);

async function onPlay(){ await enable(); transport.play(); }
function onPause(){ transport.pause(); }
</script>
<script lang="ts">
import { watch } from 'vue';
export default {};
</script>
<style scoped>
.transport{ display:flex; gap:1rem; align-items:center; margin: 1rem 0; }
label{ display:flex; gap:0.5rem; align-items:center; }
</style>
