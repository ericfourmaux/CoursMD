
class SoftClip extends AudioWorkletProcessor {
  static get parameterDescriptors(){
    return [{ name:'drive', defaultValue:1.0, minValue:0.1, maxValue:5, automationRate:'a-rate' }];
  }
  process(inputs, outputs, params){
    const input = inputs[0]; const output = outputs[0]; const drive = params.drive;
    for (let ch = 0; ch < output.length; ch++){
      const inCh = input[ch] || input[0]; const outCh = output[ch];
      for (let i=0; i<outCh.length; i++){
        const d = drive.length === 1 ? drive[0] : drive[i];
        const x = inCh ? inCh[i] * d : 0; outCh[i] = Math.tanh(x);
      }
    }
    return true;
  }
}
registerProcessor('soft-clip', SoftClip);
