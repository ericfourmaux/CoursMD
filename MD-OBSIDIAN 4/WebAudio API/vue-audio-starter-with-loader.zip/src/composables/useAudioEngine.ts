
import { ref } from 'vue';
import { AudioEngine } from '@/audio/AudioEngine';

const engine = new AudioEngine();
const running = ref(engine.context.state === 'running');

export async function enable(){
  await engine.ensureRunning();
  running.value = true;
}

export function useAudioEngine(){
  return { engine, running, enable } as const;
}
