
export async function loadSample(ctx: AudioContext, assetUrl: URL){
  const res = await fetch(assetUrl);
  const ab = await res.arrayBuffer();
  return await ctx.decodeAudioData(ab);
}
