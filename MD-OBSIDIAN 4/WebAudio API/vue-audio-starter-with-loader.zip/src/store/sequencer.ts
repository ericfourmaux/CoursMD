
export type Track = 'kick'|'snare'|'hat'|'synth';
export type Pattern = Record<Track, boolean[]>; // 16 pas

export class SequencerStore {
  bpm = 120; swing = 0.66; steps = 16; playing = false;
  pattern: Pattern = {
    kick:  Array(16).fill(false).map((_,i)=> i%4===0),
    snare: Array(16).fill(false).map((_,i)=> i%8===4),
    hat:   Array(16).fill(true),
    synth: Array(16).fill(false)
  };
}

// Singleton pratique
export const store = new SequencerStore();
