
# Vue 3 Web Audio Starter — Séquenceur + Pedalboard (Starter)

Ce starter propose une base Vue 3 + Vite pour expérimenter la Web Audio API :
- Service audio (`AudioEngine`) avec master et analyser
- Séquenceur 16 pas (store) + Transport (lookahead via Worker)
- Composants UI : Activer le son, Transport, Grille de pas, Meters, Export WAV
- Pedalboard (Delay, Reverb, Soft‑clip via AudioWorklet, EQ) — prêt à câbler

## Prérequis
- Node.js 18+ (recommandé : 20+)

## Installation
```bash
npm install
npm run dev
# build prod
npm run build
```

## À ajouter
Place tes samples dans `src/assets/` (ex. `kick.wav`, `snare.wav`, `hat.wav`) et une IR (facultatif) `ir-hall.wav`.

## Remarques
- L’audio démarre uniquement sur **geste utilisateur** (`resume()`).
- Le lookahead se fait via **Worker** (Δ=25 ms, fenêtre ≈ 150 ms).
- L’export WAV utilise `OfflineAudioContext`.



## Loader de samples (nouveau)
- Composant `SampleLoader.vue` pour charger **kick/snare/hat** (et optionnellement une IR de reverb).
- Les fichiers sont décodés en `AudioBuffer` et stockés dans le `AudioEngine`.
- Tu peux glisser/déposer ou sélectionner des fichiers.

