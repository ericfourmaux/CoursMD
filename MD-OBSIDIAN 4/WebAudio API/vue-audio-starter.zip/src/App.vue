
<template>
  <main class="container">
    <h1>🎵 Vue 3 — Web Audio Starter</h1>
    <AudioToggle />
    <TransportBar />
    <StepGrid />
    <Meters />
    <ExportPanel />
  </main>
</template>
<script setup lang="ts">
import AudioToggle from './components/AudioToggle.vue';
import TransportBar from './components/TransportBar.vue';
import StepGrid from './components/StepGrid.vue';
import Meters from './components/Meters.vue';
import ExportPanel from './components/ExportPanel.vue';
</script>
<style scoped>
.container{ max-width: 900px; margin: 2rem auto; font-family: system-ui, sans-serif; }
h1{ margin-bottom: 1rem; }
button{ cursor: pointer; }
</style>
