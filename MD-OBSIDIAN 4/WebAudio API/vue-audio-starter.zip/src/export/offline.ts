
export async function renderMixdown({ sr=44100, seconds=4 }={}){
  const off = new OfflineAudioContext(2, Math.floor(sr*seconds), sr);
  const lead = off.createOscillator(); lead.type='triangle'; lead.frequency.value=220;
  const g = off.createGain(); g.gain.value=0.3;
  lead.connect(g).connect(off.destination); lead.start(0); lead.stop(seconds);
  return await off.startRendering();
}

export function audioBufferToWav(buf: AudioBuffer){
  const numCh=buf.numberOfChannels, sr=buf.sampleRate, len=buf.length; const out=new DataView(new ArrayBuffer(44+len*numCh*2));
  const writeStr=(o:number,s:string)=>{ for(let i=0;i<s.length;i++) out.setUint8(o+i, s.charCodeAt(i)); };
  let off=0; writeStr(off,'RIFF'); off+=4; out.setUint32(off, 36+len*numCh*2, true); off+=4; writeStr(off,'WAVE'); off+=4; writeStr(off,'fmt '); off+=4;
  out.setUint32(off,16,true); off+=4; out.setUint16(off,1,true); off+=2; out.setUint16(off,numCh,true); off+=2; out.setUint32(off,sr,true); off+=4;
  out.setUint32(off,sr*numCh*2,true); off+=4; out.setUint16(off,numCh*2,true); off+=2; out.setUint16(off,16,true); off+=2; writeStr(off,'data'); off+=4; out.setUint32(off,len*numCh*2,true); off+=4;
  const chans: Float32Array[]=[]; for(let ch=0;ch<numCh;ch++) chans[ch]=buf.getChannelData(ch);
  for(let i=0;i<len;i++){ for(let ch=0;ch<numCh;ch++){ const s=Math.max(-1,Math.min(1,chans[ch][i])); out.setInt16(off, s<0?s*0x8000:s*0x7FFF, true); off+=2; } }
  return new Blob([out.buffer], { type:'audio/wav' });
}
