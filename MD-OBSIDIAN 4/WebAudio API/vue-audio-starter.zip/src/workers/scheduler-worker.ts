
self.onmessage = (e: MessageEvent) => {
  const { interval } = e.data as { interval: number };
  setInterval(() => (self as any).postMessage({}), interval);
};
