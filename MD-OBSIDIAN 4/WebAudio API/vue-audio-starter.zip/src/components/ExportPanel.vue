
<template>
  <button @click="render">Export WAV</button>
</template>
<script setup lang="ts">
import { renderMixdown, audioBufferToWav } from '@/export/offline';
async function render(){ const buf = await renderMixdown({ sr:44100, seconds:4 }); const wav = audioBufferToWav(buf); const url = URL.createObjectURL(wav); const a = document.createElement('a'); a.href=url; a.download='loop.wav'; a.click(); URL.revokeObjectURL(url); }
</script>
