
<template>
  <div class="grid">
    <div v-for="track in tracks" :key="track" class="row">
      <button v-for="(on, i) in store.pattern[track]" :key="i" class="cell" :class="{on}" @click="toggle(track,i)">{{ i+1 }}</button>
    </div>
  </div>
</template>
<script setup lang="ts">
import { store } from '@/store/sequencer';
const tracks: Array<keyof typeof store.pattern> = ['kick','snare','hat','synth'];
function toggle(track: keyof typeof store.pattern, i: number){ store.pattern[track][i] = !store.pattern[track][i]; }
</script>
<style scoped>
.grid{ display:grid; gap:6px }
.row{ display:grid; grid-template-columns: repeat(16, 1fr); gap:4px }
.cell{ padding:8px; background:#eee; border:0; }
.cell.on{ background:#1f77b4; color:white }
</style>
