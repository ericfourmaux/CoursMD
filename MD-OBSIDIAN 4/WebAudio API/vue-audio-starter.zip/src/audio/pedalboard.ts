
export function attachPedalboard(ctx: AudioContext, source: AudioNode, master: AudioNode){
  const delay = ctx.createDelay(); delay.delayTime.value = 0.28;
  const fb = ctx.createGain(); fb.gain.value = 0.35; delay.connect(fb).connect(delay);
  const wetDelay = ctx.createGain(); wetDelay.gain.value = 0.35;

  const conv = ctx.createConvolver();
  const wetRev = ctx.createGain(); wetRev.gain.value = 0.4;

  const lpf = ctx.createBiquadFilter(); lpf.type = 'lowpass'; lpf.frequency.value = 6000;

  source.connect(lpf);
  lpf.connect(delay).connect(wetDelay).connect(master);
  lpf.connect(conv).connect(wetRev).connect(master);
}
