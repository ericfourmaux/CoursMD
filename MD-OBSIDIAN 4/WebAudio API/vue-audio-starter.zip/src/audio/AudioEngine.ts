
export class AudioEngine {
  private ctx: AudioContext;
  private master: GainNode;
  private analyser: AnalyserNode;
  private buffers: Record<string, AudioBuffer> = {};

  constructor(ctx?: AudioContext){
    this.ctx = ctx ?? new AudioContext();
    this.master = this.ctx.createGain(); this.master.gain.value = 0.85;
    this.analyser = this.ctx.createAnalyser(); this.analyser.fftSize = 1024;
    this.master.connect(this.analyser).connect(this.ctx.destination);
  }

  get context(){ return this.ctx; }
  get output(){ return this.master; }
  get analyserNode(){ return this.analyser; }

  async ensureRunning(){ if (this.ctx.state !== 'running') await this.ctx.resume(); }

  async load(name: string, url: URL){
    const res = await fetch(url); const ab = await res.arrayBuffer();
    this.buffers[name] = await this.ctx.decodeAudioData(ab);
  }

  playSample(name: string, when: number, gainVal = 0.9){
    const buf = this.buffers[name]; if (!buf) return;
    const src = this.ctx.createBufferSource(); src.buffer = buf;
    const g = this.ctx.createGain(); g.gain.value = gainVal;
    src.connect(g).connect(this.master);
    src.start(when);
    src.onended = () => { try { src.disconnect(); g.disconnect(); } catch{} };
  }

  playSynth(freq: number, when: number, len = 0.2, type: OscillatorType = 'triangle'){
    const osc = this.ctx.createOscillator(); osc.type = type; osc.frequency.value = freq;
    const g = this.ctx.createGain(); g.gain.value = 0;
    osc.connect(g).connect(this.master);
    g.gain.setValueAtTime(0, when);
    g.gain.linearRampToValueAtTime(0.8, when + 0.01);
    g.gain.linearRampToValueAtTime(0, when + len);
    osc.start(when); osc.stop(when + len + 0.02);
  }
}
