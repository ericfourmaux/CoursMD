
export function startScheduler(interval = 25, tick: () => void){
  const url = new URL('../workers/scheduler-worker.ts', import.meta.url);
  const worker = new Worker(url, { type: 'module' });
  worker.onmessage = () => tick();
  worker.postMessage({ interval });
  return worker;
}
