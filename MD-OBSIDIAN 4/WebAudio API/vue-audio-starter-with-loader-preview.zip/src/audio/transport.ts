
import { store } from '@/store/sequencer';
import { AudioEngine } from '@/audio/AudioEngine';
import { startScheduler } from '@/audio/scheduler';

export class Transport {
  constructor(private engine: AudioEngine){}
  private worker?: Worker; private nextNoteTime = 0; private currentStep = 0;

  secondsPerStep(){ return (60/store.bpm) / 4; }
  swingOffset(step: number, sp: number){ return (step%2===1) ? (store.swing - 0.5)*sp : 0; }

  async play(){ await this.engine.ensureRunning(); store.playing = true;
    this.currentStep = 0; this.nextNoteTime = this.engine.context.currentTime + 0.05;
    this.worker = startScheduler(25, () => this.scheduler());
  }
  pause(){ store.playing = false; if (this.worker) this.worker.terminate(); }

  scheduler(){ const sp = this.secondsPerStep(); const ctx = this.engine.context;
    while (this.nextNoteTime < ctx.currentTime + 0.15){
      const t = this.nextNoteTime + this.swingOffset(this.currentStep, sp);
      this.scheduleStep(this.currentStep, t); this.nextNoteTime += sp;
      this.currentStep = (this.currentStep + 1) % store.steps;
    }
  }

  scheduleStep(step: number, time: number){
    const p = store.pattern;
    if (p.kick[step])  this.engine.playSample('kick',  time, 0.9);
    if (p.snare[step]) this.engine.playSample('snare', time, 0.9);
    if (p.hat[step])   this.engine.playSample('hat',   time, 0.6);
    if (p.synth[step]) this.engine.playSynth(220, time, 0.18, 'sawtooth');
  }
}
