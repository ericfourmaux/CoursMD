
export async function loadSoftClipWorklet(ctx: AudioContext){
  const url = new URL('../worklets/soft-clip.js', import.meta.url);
  await ctx.audioWorklet.addModule(url);
  return new AudioWorkletNode(ctx, 'soft-clip');
}
