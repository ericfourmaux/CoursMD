
<template>
  <section class="loader">
    <h2>🎛️ Loader de samples</h2>
    <p>Charge des fichiers audio pour <strong>kick</strong>, <strong>snare</strong> et <strong>hat</strong>. Tu peux glisser/déposer ou sélectionner.</p>

    <div class="rows">
      <div class="row">
        <label>Kick</label>
        <input type="file" accept="audio/*" @change="onFile('kick', $event)" />
        <span class="status" :class="{ok: engine.hasSample('kick')}">{{ engine.hasSample('kick') ? 'chargé' : 'manquant' }}</span>
      </div>
      <div class="row">
        <label>Snare</label>
        <input type="file" accept="audio/*" @change="onFile('snare', $event)" />
        <span class="status" :class="{ok: engine.hasSample('snare')}">{{ engine.hasSample('snare') ? 'chargé' : 'manquant' }}</span>
      </div>
      <div class="row">
        <label>Hat</label>
        <input type="file" accept="audio/*" @change="onFile('hat', $event)" />
        <span class="status" :class="{ok: engine.hasSample('hat')}">{{ engine.hasSample('hat') ? 'chargé' : 'manquant' }}</span>
      </div>
    </div>

    <div class="drop" @dragover.prevent @drop.prevent="onDrop">
      Glisse tes fichiers ici (kick/snare/hat)
    </div>

    <div class="summary">
      <strong>Samples chargés :</strong> {{ samples.join(', ') || 'aucun' }}
    </div>
  </section>
</template>
<script setup lang="ts">
import { computed } from 'vue';
import { useAudioEngine } from '@/composables/useAudioEngine';
const { engine } = useAudioEngine();

function onFile(name: 'kick'|'snare'|'hat', ev: Event){
      
    }

    function onPreview(name: 'kick'|'snare'|'hat'){
      engine.previewSample(name);
    }

    function onFile(name: 'kick'|'snare'|'hat', ev: Event){
  const input = ev.target as HTMLInputElement;
  const file = input.files?.[0]; if (!file) return;
  engine.loadFromFile(name, file);
}

function onDrop(ev: DragEvent){
  const files = ev.dataTransfer?.files; if (!files) return;
  for (let i=0; i<files.length; i++){
    const f = files[i];
    const lname = f.name.toLowerCase();
    if (lname.includes('kick')) engine.loadFromFile('kick', f);
    else if (lname.includes('snare')) engine.loadFromFile('snare', f);
    else if (lname.includes('hat') || lname.includes('hh')) engine.loadFromFile('hat', f);
  }
}

const samples = computed(()=> engine.listSamples());
</script>
<style scoped>
.loader{ border:1px solid #ddd; padding:1rem; border-radius:8px; margin:1rem 0; }
.rows{ display:grid; gap:0.5rem; }
.row{ display:flex; gap:0.5rem; align-items:center; }
    .preview{ padding:0.25rem 0.5rem; }
.row label{ width:70px; font-weight:600; }
.status{ font-size:0.9rem; color:#888; }
.status.ok{ color:#1f77b4; font-weight:600; }
.drop{ margin-top:0.75rem; padding:0.75rem; border:2px dashed #ccc; border-radius:8px; text-align:center; color:#666; }
.summary{ margin-top:0.75rem; font-size:0.95rem; }
</style>
