import argon2 from 'argon2';

export async function hashPassword(pwd) {
  return argon2.hash(pwd, { type: argon2.argon2id, memoryCost: 19*1024, timeCost: 2, parallelism: 1 });
}
export async function verifyPassword(hash, pwd) {
  return argon2.verify(hash, pwd);
}
