import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import session from 'express-session';
import { rateLimit } from 'express-rate-limit';
import csrf from '@dr.pogodin/csurf';

import authRoutes from './routes/auth.js';
import jwtRoutes from './routes/jwt.js';

const app = express();
app.set('trust proxy', 1);
app.use(helmet());
app.use(express.json());
app.use(cookieParser());

// Session cookies Secure+HttpOnly+SameSite
app.use(session({
  name: '__Host.sid',
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { path: '/', httpOnly: true, secure: true, sameSite: 'lax', maxAge: 60*60*1000 }
}));

// Rate limit sur login
const loginLimiter = rateLimit({ windowMs: 15*60*1000, limit: 10, standardHeaders: 'draft-8', legacyHeaders: false });

// CSRF (token en cookie + champ hidden dans formulaires)
app.use(csrf({ cookie: { key: '_csrf', httpOnly: true, secure: true, sameSite: 'lax' } }));

app.get('/', (req, res) => {
  res.json({ ok: true, csrfToken: req.csrfToken(), message: 'Mini-projet Express Auth' });
});

app.use('/auth', loginLimiter, authRoutes);
app.use('/api', jwtRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚀 Serveur sur https://localhost:${PORT}`));
