import { Router } from 'express';
import { hashPassword, verifyPassword } from '../utils/password.js';

// Démo: utilisateur en mémoire
const user = { id: 'u1', username: 'eric', passwordHash: await hashPassword('test1234'), role: 'user' };

const router = Router();

router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  if (username !== user.username) return res.status(401).json({ error: 'Invalid credentials' });
  const ok = await verifyPassword(user.passwordHash, password);
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
  req.session.userId = user.id;
  res.json({ ok: true });
});

router.post('/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

router.get('/profile', (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: 'Not authenticated' });
  res.json({ id: user.id, username: user.username, role: user.role });
});

export default router;
