import { Router } from 'express';
import jwt from 'jsonwebtoken';
import { requireJwt } from '../middleware/jwt-auth.js';

const router = Router();

// In-memory refresh store (par utilisateur)
const refreshStore = new Map();

function signAccess(user) {
  return jwt.sign({ sub: user.id, role: user.role }, process.env.ACCESS_PRIVATE_KEY, {
    algorithm: 'RS256', expiresIn: '15m', issuer: 'mini-projet-api'
  });
}
function signRefresh(user) {
  return jwt.sign({ sub: user.id }, process.env.ACCESS_PRIVATE_KEY, {
    algorithm: 'RS256', expiresIn: '7d', issuer: 'mini-projet-api', jwtid: crypto.randomUUID()
  });
}

// Démo user
const user = { id: 'u1', role: 'user' };

router.post('/auth/login', (req, res) => {
  const access = signAccess(user);
  const refresh = signRefresh(user);
  refreshStore.set(user.id, refresh);
  res.cookie('refresh', refresh, { httpOnly: true, secure: true, sameSite: 'lax', path: '/api/auth' });
  res.json({ access });
});

router.post('/auth/refresh', (req, res) => {
  const refresh = req.cookies?.refresh;
  if (!refresh) return res.status(401).json({ error: 'Missing refresh' });
  try {
    const payload = jwt.verify(refresh, process.env.ACCESS_PRIVATE_KEY, { algorithms: ['RS256'], issuer: 'mini-projet-api' });
    const current = refreshStore.get(payload.sub);
    if (current !== refresh) {
      // rotation + détection de réutilisation
      refreshStore.delete(payload.sub);
      return res.status(403).json({ error: 'Refresh reuse detected' });
    }
    const newAccess = signAccess({ id: payload.sub, role: 'user' });
    const newRefresh = signRefresh({ id: payload.sub, role: 'user' });
    refreshStore.set(payload.sub, newRefresh);
    res.cookie('refresh', newRefresh, { httpOnly: true, secure: true, sameSite: 'lax', path: '/api/auth' });
    res.json({ access: newAccess });
  } catch (e) {
    return res.status(401).json({ error: 'Invalid refresh' });
  }
});

router.get('/protected', requireJwt, (req, res) => {
  res.json({ ok: true, user: req.user });
});

export default router;
