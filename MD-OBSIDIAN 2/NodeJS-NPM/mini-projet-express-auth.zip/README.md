# Mini-projet Express Auth

Ce mini-projet montre **sessions côté serveur** + **JWT avec rotation de refresh** et protections **Helmet/CSRF/rate-limit**.

## Lancer
```bash
npm install
cp .env.example .env # remplissez les secrets
npm run dev
```

## Endpoints
- `POST /auth/login` : session cookie + CSRF actif (retourne `{ ok: true }`).
- `GET /auth/profile` : profil si session active.
- `POST /auth/logout` : détruit la session.
- `POST /api/auth/login` : émet `access` (15 min) et cookie `refresh` (7 jours).
- `POST /api/auth/refresh` : **rotation** du refresh, détecte réutilisation.
- `GET /api/protected` : nécessite `Authorization: Bearer <access>`.

## Sécurité (références)
- Cookies `Secure`/`HttpOnly`/`SameSite` + préfixe `__Host` recommandés (MDN). 
- Sessions Express: cookies d'ID, données côté serveur (Express docs). 
- Helmet: HSTS, CSP, etc.
- CSRF: tokens (OWASP), fork maintenu `@dr.pogodin/csurf`.
- JWT: algos explicites, RS256 recommandé (RFC 7519).
- Refresh **rotation** (Auth0). 

Cf. Chapitre 7 pour détails et liens.
