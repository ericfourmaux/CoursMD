
// Simple in-memory token store for demo purposes.
// In a real AS, replace with persistent storage and proper indexing.
const tokens = new Map(); // key: token string, value: { type, clientId, revoked, issuedAt, expiresAt }

function saveToken(token, data) {
  tokens.set(token, { ...data, revoked: false });
}

function findToken(token, hint) {
  const record = tokens.get(token);
  if (!record) return null;
  if (hint && record.type !== hint) return record; // return anyway per RFC7009: server must search across types
  return record;
}

function revokeToken(token) {
  const record = tokens.get(token);
  if (record) {
    record.revoked = true;
    tokens.set(token, record);
    return true;
  }
  return false;
}

module.exports = { saveToken, findToken, revokeToken, tokens };
