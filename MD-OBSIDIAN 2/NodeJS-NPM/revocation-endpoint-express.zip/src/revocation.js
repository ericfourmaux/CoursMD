
/**
 * RFC 7009 OAuth 2.0 Token Revocation endpoint
 * - POST application/x-www-form-urlencoded
 * - Parameters: token (REQUIRED), token_type_hint (OPTIONAL)
 * - Client authentication: basic auth or client_id/client_secret in body (demo)
 * - Always respond 200 OK (even if token invalid / already revoked)
 *
 * See RFC 7009 §2, §2.1, §2.2, §2.3
 */
const express = require('express');
const router = express.Router();
const { revokeToken, findToken } = require('./tokenStore');

function parseBasicAuth(header) {
  if (!header || !header.startsWith('Basic ')) return null;
  const b64 = header.slice('Basic '.length).trim();
  try {
    const decoded = Buffer.from(b64, 'base64').toString('utf8');
    const sep = decoded.indexOf(':');
    if (sep < 0) return null;
    return { clientId: decoded.slice(0, sep), clientSecret: decoded.slice(sep + 1) };
  } catch (_) {
    return null;
  }
}

function authenticateClient(req) {
  // Try HTTP Basic first
  const basic = parseBasicAuth(req.headers.authorization);
  if (basic) return basic;
  // Fallback to form parameters
  const { client_id, client_secret } = req.body;
  if (client_id && client_secret) return { clientId: client_id, clientSecret: client_secret };
  return null;
}

function verifyClient({ clientId, clientSecret }, env) {
  // Demo: compare against env vars. Replace with your client authentication.
  return clientId === env.REVOCATION_CLIENT_ID && clientSecret === env.REVOCATION_CLIENT_SECRET;
}

router.post('/oauth/revoke', express.urlencoded({ extended: false }), (req, res) => {
  const auth = authenticateClient(req);
  if (!auth || !verifyClient(auth, process.env)) {
    // Per RFC 7009 the request MUST be authenticated (client auth).
    // If auth fails: 401 Unauthorized.
    return res.status(401).json({ error: 'invalid_client' });
  }

  const token = req.body.token;
  const hint = req.body.token_type_hint; // 'access_token' or 'refresh_token' per RFC

  if (!token) {
    // RFC 7009 §2.1: token is REQUIRED.
    return res.status(400).json({ error: 'invalid_request', error_description: 'token is required' });
  }

  // Attempt lookup (server MUST handle unknown hint by searching across types)
  const record = findToken(token, hint);

  // Revoke if found; per RFC 7009 §2.2 return 200 OK regardless
  if (record) {
    revokeToken(token);
  }

  // CORS (RFC 7009 §2.3 suggests supporting cross-origin)
  res.set('Access-Control-Allow-Origin', '*');
  res.set('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.status(200).send(); // Empty body per spec
});

module.exports = router;
