
const express = require('express');
const morgan = require('morgan');
const cors = require('cors');
require('dotenv').config();

const { saveToken } = require('./tokenStore');
const revocation = require('./revocation');

const app = express();
app.use(morgan('dev'));
app.use(cors());

// Demo endpoint to issue/store tokens locally (not part of RFC7009)
app.post('/demo/issue', express.json(), (req, res) => {
  const { token, type = 'access_token', clientId = 'demo-client', expiresIn = 3600 } = req.body;
  if (!token) return res.status(400).json({ error: 'token required' });
  const now = Math.floor(Date.now() / 1000);
  saveToken(token, { type, clientId, issuedAt: now, expiresAt: now + expiresIn });
  res.status(201).json({ token, type, clientId, expiresAt: now + expiresIn });
});

// Revocation endpoint per RFC 7009
app.use(revocation);

const port = process.env.PORT || 3001;
app.listen(port, () => {
  console.log(`Revocation endpoint listening on http://localhost:${port}`);
});
