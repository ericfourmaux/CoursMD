
# OAuth 2.0 Token Revocation (RFC 7009) — Express.js

Endpoint: `POST /oauth/revoke` — conforms to RFC 7009.

## Features
- `token` (REQUIRED) and `token_type_hint` (OPTIONAL: `access_token` | `refresh_token`).
- Client authentication via HTTP Basic or `client_id`/`client_secret` in body (demo).
- Always responds **200 OK** per spec, even if token was invalid or already revoked.
- CORS headers set for cross-origin support.

## Quick start
```bash
npm install
cp .env.sample .env
npm start
```

### Issue a demo token (for testing)
```bash
curl -X POST http://localhost:3001/demo/issue   -H 'Content-Type: application/json'   -d '{"token":"t-123","type":"refresh_token","clientId":"demo-client","expiresIn":7200}'
```

### Revoke a token (HTTP Basic)
```bash
curl -X POST http://localhost:3001/oauth/revoke   -H 'Authorization: Basic ZGVtby1jbGllbnQ6ZGVtby1zZWNyZXQ='   -H 'Content-Type: application/x-www-form-urlencoded'   -d 'token=t-123&token_type_hint=refresh_token'
# => 200 OK (empty body)
```

### Revoke a token (form client_id/client_secret)
```bash
curl -X POST http://localhost:3001/oauth/revoke   -H 'Content-Type: application/x-www-form-urlencoded'   -d 'token=t-123&token_type_hint=refresh_token&client_id=demo-client&client_secret=demo-secret'
# => 200 OK
```

## Notes
- Spec references:
  - RFC 7009 defines the revocation endpoint, parameters, and **200 OK** behavior: https://www.rfc-editor.org/rfc/rfc7009 
  - oauth.net overview of Token Revocation: https://oauth.net/2/token-revocation/ 
- If you expose an **introspection** endpoint (RFC 7662), you can verify a token’s `active` state after revocation: https://www.rfc-editor.org/info/rfc7662
- In production, use a real client authentication (mTLS, private_key_jwt, etc.) and a persistent token store.
